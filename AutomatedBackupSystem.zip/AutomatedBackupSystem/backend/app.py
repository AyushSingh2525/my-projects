from flask import Flask, render_template, request, redirect, url_for, session
import os
import mysql.connector
import hashlib
import time
from datetime import datetime
from config import DB_CONFIG

app = Flask(__name__)
app.secret_key = "backup-system-secret-key"

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

def calculate_sha256(file_path):

    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:

        while True:

            data = file.read(4096)

            if not data:
                break

            sha256.update(data)

    return sha256.hexdigest()

@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # Temporary login
        # MySQL will be connected later
        if username == "Ayush" and password == "Ayush123":
            session["user"] = username
            return redirect(url_for("dashboard"))

        return render_template(
            "login.html",
            error="Invalid username or password"
        )

    return render_template("index.html")


@app.route("/dashboard")
def dashboard():

    if "user" not in session:
        return redirect(url_for("login"))

    stats = {
        "total_backups": 25,
        "verified_backups": 20,
        "successful_tests": 18,
        "failed_tests": 2,
        "success_rate": 90
    }

    recent_tests = [
        {
            "backup": "College Database",
            "test": "Integrity Verification",
            "result": "PASS",
            "time": "2 minutes ago"
        },
        {
            "backup": "Student Management DB",
            "test": "Recovery Test",
            "result": "PASS",
            "time": "15 minutes ago"
        },
        {
            "backup": "Library Database",
            "test": "Integrity Verification",
            "result": "FAIL",
            "time": "1 hour ago"
        },
        {
            "backup": "Attendance Database",
            "test": "Recovery Test",
            "result": "PASS",
            "time": "2 hours ago"
        }
    ]

    return render_template(
        "dashboard.html",
        stats=stats,
        recent_tests=recent_tests
    )

@app.route("/backups/add", methods=["GET", "POST"])
def add_backup():

    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":

        backup_name = request.form["backup_name"]
        backup_type = request.form["backup_type"]

        file = request.files.get("backup_file")

        if not file or file.filename == "":
            return render_template(
                "add_backup.html",
                error="Please select a backup file."
            )

        os.makedirs("backups", exist_ok=True)

        filename = file.filename

        file_path = os.path.join(
            "backups",
            filename
        )

        file.save(file_path)

        file_size = os.path.getsize(file_path)
        hash_value = calculate_sha256(file_path)

        connection = get_db_connection()

        cursor = connection.cursor()

        query = """
            INSERT INTO backups
            (
                backup_name,
                backup_type,
                file_path,
                file_size,
                hash_value,
                status
            )
            VALUES (%s, %s, %s, %s, %s,%s)
        """

        values = (
            backup_name,
            backup_type,
            file_path,
            file_size,
            hash_value,
            "Pending"
        )

        cursor.execute(query, values)

        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for("backup_list"))

    return render_template("add_backup.html")

@app.route("/backups/verify/<int:backup_id>")
def verify_backup(backup_id):

    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()

    cursor = connection.cursor(dictionary=True)

    cursor.execute(
        """
        SELECT *
        FROM backups
        WHERE id = %s
        """,
        (backup_id,)
    )

    backup = cursor.fetchone()

    if not backup:

        cursor.close()
        connection.close()

        return "Backup not found", 404

    file_path = backup["file_path"]

    # TEST 1: File Exists   

    if not os.path.exists(file_path):

        cursor.execute(
            """
            UPDATE backups
            SET status = 'Failed'
            WHERE id = %s
            """,
            (backup_id,)
        )

        cursor.execute(
            """
            INSERT INTO verification_tests
            (
                backup_id,
                test_type,
                test_status,
                message
            )
            VALUES (%s, %s, %s, %s)
            """,
            (
                backup_id,
                "File Existence",
                "FAIL",
                "Backup file does not exist."
            )
        )

        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for("backup_list"))

    # TEST 2: File Size

    current_size = os.path.getsize(file_path)

    if current_size <= 0:

        cursor.execute(
            """
            UPDATE backups
            SET status = 'Failed'
            WHERE id = %s
            """,
            (backup_id,)
        )

        cursor.execute(
            """
            INSERT INTO verification_tests
            (
                backup_id,
                test_type,
                test_status,
                message
            )
            VALUES (%s, %s, %s, %s)
            """,
            (
                backup_id,
                "File Size",
                "FAIL",
                "Backup file is empty."
            )
        )

        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for("backup_list"))

    # TEST 3: SHA-256

    current_hash = calculate_sha256(file_path)

    stored_hash = backup["hash_value"]


    if current_hash != stored_hash:

        cursor.execute(
            """
            UPDATE backups
            SET status = 'Failed'
            WHERE id = %s
            """,
            (backup_id,)
        )

        cursor.execute(
            """
            INSERT INTO verification_tests
            (
                backup_id,
                test_type,
                test_status,
                message
            )
            VALUES (%s, %s, %s, %s)
            """,
            (
                backup_id,
                "SHA-256 Integrity",
                "FAIL",
                "Hash mismatch. Backup may have been modified or corrupted."
            )
        )

        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for("backup_list"))

    # ALL TESTS PASSED

    cursor.execute(
        """
        UPDATE backups
        SET status = 'Verified'
        WHERE id = %s
        """,
        (backup_id,)
    )


    cursor.execute(
        """
        INSERT INTO verification_tests
        (
            backup_id,
            test_type,
            test_status,
            message
        )
        VALUES (%s, %s, %s, %s)
        """,
        (
            backup_id,
            "Complete Verification",
            "PASS",
            "File exists, file size is valid and SHA-256 integrity check passed."
        )
    )


    connection.commit()

    cursor.close()
    connection.close()

    return redirect(url_for("backup_list"))

@app.route("/backups/recover/<int:backup_id>")
def recover_backup(backup_id):

    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    # Get backup
    cursor.execute(
        """
        SELECT *
        FROM backups
        WHERE id = %s
        """,
        (backup_id,)
    )

    backup = cursor.fetchone()

    if not backup:
        cursor.close()
        connection.close()
        return "Backup not found", 404

    # Backup must be verified
    if backup["status"] != "Verified":
        cursor.close()
        connection.close()

        return "Backup must be verified before recovery testing.", 400

    file_path = backup["file_path"]

    # Check file exists
    if not os.path.exists(file_path):
        cursor.close()
        connection.close()

        return "Backup file does not exist.", 404

    # Temporary database name
    timestamp = int(time.time())

    temporary_database = (
        f"recovery_test_{backup_id}_{timestamp}"
    )

    start_time = time.time()

    try:

        # Create temporary database
        temp_connection = mysql.connector.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"]
        )

        temp_cursor = temp_connection.cursor()

        temp_cursor.execute(
            f"CREATE DATABASE `{temporary_database}`"
        )

        temp_cursor.close()
        temp_connection.close()

        # Connect to temporary database
        recovery_connection = mysql.connector.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=temporary_database
        )

        recovery_cursor = recovery_connection.cursor()

        # Read SQL backup
        with open(
            file_path,
            "r",
            encoding="utf-8"
        ) as file:

            sql_script = file.read()

        # Execute SQL statements
        statements = sql_script.split(";")

        for statement in statements:

            statement = statement.strip()

            if statement:
                recovery_cursor.execute(statement)

        recovery_connection.commit()

        # Check restored tables
        recovery_cursor.execute("SHOW TABLES")

        tables = recovery_cursor.fetchall()

        tables_restored = len(tables)

        recovery_cursor.close()
        recovery_connection.close()

        recovery_time = time.time() - start_time

        # Save recovery result
        cursor.execute(
            """
            INSERT INTO recovery_tests
            (
                backup_id,
                temporary_database,
                tables_expected,
                tables_restored,
                records_expected,
                records_restored,
                recovery_time,
                status,
                message
            )
            VALUES
            (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                backup_id,
                temporary_database,
                0,
                tables_restored,
                0,
                0,
                recovery_time,
                "SUCCESS",
                "Backup successfully restored and tables detected."
            )
        )

        connection.commit()

        cursor.close()
        connection.close()

        return render_template(
            "recovery_result.html",
            backup=backup,
            temporary_database=temporary_database,
            tables_restored=tables_restored,
            recovery_time=round(recovery_time, 2),
            status="SUCCESS",
            message="Backup successfully restored and tables detected."
        )

    except Exception as e:

        recovery_time = time.time() - start_time

        cursor.execute(
            """
            INSERT INTO recovery_tests
            (
                backup_id,
                temporary_database,
                recovery_time,
                status,
                message
            )
            VALUES
            (%s, %s, %s, %s, %s)
            """,
            (
                backup_id,
                temporary_database,
                recovery_time,
                "FAILED",
                str(e)
            )
        )

        connection.commit()

        cursor.close()
        connection.close()

        return f"Recovery Test Failed: {e}", 500

@app.route("/backups")
def backup_list():

    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()

    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT *
        FROM backups
        ORDER BY created_at DESC
    """)

    backups = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "backups.html",
        backups=backups
    )

def calculate_sha256(file_path):

    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:

        while True:

            data = file.read(4096)

            if not data:
                break

            sha256.update(data)

    return sha256.hexdigest()

def restore_sql_backup(file_path, database_name):

    connection = mysql.connector.connect(
        host=DB_CONFIG["host"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"]
    )

    cursor = connection.cursor()

    # Create temporary database
    cursor.execute(
        f"CREATE DATABASE `{database_name}`"
    )

    cursor.close()
    connection.close()

    # Connect to temporary database
    recovery_connection = mysql.connector.connect(
        host=DB_CONFIG["host"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"],
        database=database_name
    )

    recovery_cursor = recovery_connection.cursor()

    # Read SQL backup
    with open(
        file_path,
        "r",
        encoding="utf-8"
    ) as file:

        sql_script = file.read()

    # Execute SQL statements
    statements = sql_script.split(";")

    for statement in statements:

        statement = statement.strip()

        if statement:

            recovery_cursor.execute(statement)

    recovery_connection.commit()

    recovery_cursor.close()
    recovery_connection.close()

@app.route("/recovery-testing")
def recovery_testing():
    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            recovery_tests.id,
            recovery_tests.temporary_database,
            recovery_tests.tables_restored,
            recovery_tests.recovery_time,
            recovery_tests.status,
            recovery_tests.message,
            recovery_tests.tested_at,
            backups.backup_name
        FROM recovery_tests
        LEFT JOIN backups
            ON backups.id = recovery_tests.backup_id
        ORDER BY recovery_tests.tested_at DESC, recovery_tests.id DESC
    """)

    recovery_tests = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template(
        "recovery.html",
        recovery_tests=recovery_tests
    )

@app.route("/test-history")
def test_history():
    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            recovery_tests.*,
            backups.backup_name
        FROM recovery_tests
        LEFT JOIN backups
            ON backups.id = recovery_tests.backup_id
        ORDER BY recovery_tests.tested_at DESC, recovery_tests.id DESC
    """)

    tests = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template("test_history.html", tests=tests)

@app.route("/reports")
def reports():
    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            COUNT(*) AS total_backups,
            COALESCE(SUM(status = 'Verified'), 0) AS verified_backups
        FROM backups
    """)
    backup_stats = cursor.fetchone()

    cursor.execute("""
        SELECT
            COALESCE(SUM(status = 'SUCCESS'), 0) AS successful_tests,
            COALESCE(SUM(status = 'FAILED'), 0) AS failed_tests
        FROM recovery_tests
    """)
    test_stats = cursor.fetchone()

    cursor.execute("""
        SELECT
            recovery_tests.status,
            recovery_tests.tables_restored,
            recovery_tests.recovery_time,
            recovery_tests.tested_at,
            backups.backup_name
        FROM recovery_tests
        LEFT JOIN backups ON backups.id = recovery_tests.backup_id
        ORDER BY recovery_tests.tested_at DESC, recovery_tests.id DESC
        LIMIT 1
    """)
    latest_test = cursor.fetchone()

    cursor.close()
    connection.close()

    return render_template(
        "reports.html",
        total_backups=backup_stats["total_backups"],
        verified_backups=backup_stats["verified_backups"],
        successful_tests=test_stats["successful_tests"],
        failed_tests=test_stats["failed_tests"],
        latest_test=latest_test
    )

@app.route("/verification")
def verification():
    if "user" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT id, backup_name, file_path, status
        FROM backups
        ORDER BY id DESC
    """)

    backups = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template("verification.html", backups=backups)
       
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)