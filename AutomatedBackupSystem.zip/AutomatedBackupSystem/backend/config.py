DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "Ayush2525",
    "database": "backup_recovery_system"
}